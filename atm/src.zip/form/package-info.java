/**
 * Account객체, Transaction객체, DAO 등 폼이 담겨있다.
 */
package form;