/**
 * GUI관련 코드가 위치해 있다. FXML, FXML-Controller 등
 */
package application;